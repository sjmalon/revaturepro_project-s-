package dp;

public class Brakes extends CarPart{
	
	public final int number=4;
	
	public void slow_car() {
		
	}
	
	public void function() {
		System.out.println("[Brakes: These parts slow and/or stop the "
				+ "car when needed; there are four of them.]");
	}

}
