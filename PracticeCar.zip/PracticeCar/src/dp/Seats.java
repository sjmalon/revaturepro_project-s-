package dp;

public class Seats extends CarPart{
	
	public final int number=5;
	
	public void function() {
		System.out.println("[Seats: These parts allow the "
				+ "car's passengers to sit comfortably while the "
				+ "car moves; there are 5 of them.]");
	}

}
