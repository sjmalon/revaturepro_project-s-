package dp;

public class Steering_Wheel extends CarPart{ 
	
	public String position="up";
	
	public void turn() {
		
	}
	
	public void function() {
		System.out.println("[Steering Wheel: This part steers "
				+ "the car; for ease of handling and comfort its "
				+ "position can be adjusted to shift either up or "
				+ "down.]");
	}

}
