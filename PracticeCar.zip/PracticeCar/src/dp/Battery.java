package dp;

public class Battery extends CarPart{
	
	public String dead="no";
	
	public void generate_electricity() {
		
	}
	
	public void function() {
		System.out.println("[Battery: This part provides "
				+ "electricity for the car; it can be either "
				+ "dead or not dead.]");
	}

}
