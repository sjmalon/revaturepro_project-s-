package dp;

public class Body extends CarPart{
	
	public final String material="Steel";
	
	public void function() {
		System.out.println("[Body: This part encloses the "
				+ "seats for the driver and the "
				+ "passengers; it is made of steel.]");
	}

}
