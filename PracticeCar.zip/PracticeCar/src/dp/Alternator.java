package dp;

public class Alternator extends CarPart{
	
	public String power="off";
	
	public void generate_electricity() {
		
	}
	
	public void function() {
		System.out.println("[Alternator: This parts converts "
				+ "mechanical energy to "
				+ "electrical energy; it can be on or off.]");
	}

}
