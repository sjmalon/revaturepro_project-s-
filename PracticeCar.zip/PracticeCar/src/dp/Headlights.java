package dp;

public class Headlights extends CarPart{
	
	public final int number=2;
	
	public void activate() {
		
	}
	
	public void function() {
		System.out.println("[Headlights: These parts provide "
				+ "light for the road when it's "
				+ "dark; there are two them.]");
	}

}
