package dp;

public class Radiator extends CarPart{
	
	public final String fluid="Anti-freeze";
	
	public void activate() {
		
	}
	
	public void function() {
		
		System.out.println("[Radiator: This part eliminates "
				+ "heat from the engine when "
				+ "its running; the fluid that absorbs the heat is called "
				+ "anti-freeze.]");
	}

}
