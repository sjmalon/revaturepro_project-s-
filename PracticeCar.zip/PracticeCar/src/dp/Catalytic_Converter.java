package dp;

public class Catalytic_Converter extends CarPart{
	
	public String power="off";
	
	public void filter_toxins() {
		
	}
	
	public void function() {
		System.out.println("[Catalytic Converter: This "
				+ "part converts harmful substances "
				+ "expelled in the car's exhaust to "
				+ "less harmful byproducts such as "
				+ "water vapor or carbon dioxide; it can "
				+ "be either on or off.]");
	}

}
