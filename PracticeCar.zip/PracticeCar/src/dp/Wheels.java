package dp;

public class Wheels extends CarPart{
	
	public final int number=4;
	
	public void roll() {
		
	}
	
	public void function() {
		System.out.println("[Wheels: These parts allow the car to "
				+ "roll to move it places; there are four of them.]");
	}

}
