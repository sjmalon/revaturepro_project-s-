package dp;

public class Gas_Pedal extends CarPart{
	
	public String position="up";
	
	public void actuate_engine() {
		
	}
	
	public void function() {
		System.out.println("[Gas Pedal: This part allows the car's "
				+ "driver to actuate the car's "
				+ "engine; it can be either pushed down by the "
				+ "driver's foot to actuate the engine or "
				+ "left up which will make the car remain "
				+ "idle.]");
	}

}
