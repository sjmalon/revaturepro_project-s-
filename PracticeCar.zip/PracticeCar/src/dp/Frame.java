package dp;

public class Frame extends CarPart {
	
	public final String material="steel";
	
	public void function() {
		System.out.println("[Frame: This part is the main supporting "
				+ "structure that all other parts are attatched to; "
				+ "it is made of steel.]");
	}

}
