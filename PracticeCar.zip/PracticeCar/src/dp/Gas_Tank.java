package dp;

public class Gas_Tank extends CarPart{
	
	public int level=100;
	
	public void provide_gas() {
		
	}
	
	public void function() {
		System.out.println("[Gas Tank: This part stores the fuel "
				+ "used in the engine; its capacity can be anywhere "
				+ "between full and empty.]");
	}

}
