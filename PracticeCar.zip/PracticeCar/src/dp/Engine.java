package dp;

public class Engine extends CarPart {
	
	public final int cylinders=6;
	public String running="yes";
	
	public void generate_mechanical_energy() {
		
	}
	
	public void function() {
		System.out.println("[Engine: This part converts the energy in fuel "
				+ "to mechanical energy to move the car; it has six "
				+ "cylinders; it can be running or not.]");
	}

}
