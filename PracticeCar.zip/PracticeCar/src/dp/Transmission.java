package dp;

public class Transmission extends CarPart{
	
	public final String Automatic="yes";
	
	public void activate() {
		
	}
	
	public void function() {
		System.out.println("[Transmission: This part ensures that "
				+ "a certain amount of power "
				+ "goes to the car's wheels "
				+ "at a certain speed; this particular transmission "
				+ "is automatic.]");
	}

}
