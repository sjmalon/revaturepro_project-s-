package dp;

public class Speedometer extends CarPart{
	
	public final int maxSpeed=120;
	public final int minSpeed=0;
	
	public void activate() {
		
	}
	
	public void function() {
		System.out.println("[Speedometer: This part gauges "
				+ "the speed of the car; it has a maximum "
				+ "speed of 120 and a minimum of 0.]");
	}

}
