package dp;

public class Simulator extends CarPart{
	
	public static void main(String[] args) {
		Car car=new Car();
		car.run();
	}

}
