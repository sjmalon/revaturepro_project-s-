package dp;

public class CarPart implements Functional {
	
	private int condition=100;
	public void status() {
		System.out.println(condition);
	}
	
	public void setCondition(int condition) {
		if (condition>= 0) {
			this.condition=condition;
		}
		
		else {
			this.condition=0;
		}
	};
	
	public void function() {
	};

}
