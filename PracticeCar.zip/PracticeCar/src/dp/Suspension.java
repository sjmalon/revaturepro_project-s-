package dp;

public class Suspension extends CarPart{
	
	public final int number=2;
	public final int tires=4;
	public int tread_level=100;
	
	public void function() {
		System.out.println("[Suspension: These parts help the car "
				+ "absorb bumps in the road "
				+ "to help provide a safe and "
				+ "comfortable ride; there are two sets of suspension "
				+ "systems and four tires that are a part of them; "
				+ "their tires can have tread levels that range from "
				+ "100 to 0.]");
	}

}
