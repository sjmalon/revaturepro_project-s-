package dp;

import java.util.ArrayList;
import java.util.List;

public class Car {
	
	public String power="off";
	
	List<CarPart> collection=new ArrayList<>();
		
	public Car() {
		
		CarPart alternator=new Alternator();
		CarPart axles=new Axles();
		CarPart battery=new Battery();
		CarPart body=new Body();
		CarPart brakes=new Brakes();
		CarPart cc=new Catalytic_Converter();
		CarPart engine=new Engine();
		CarPart frame=new Frame();
		CarPart gp=new Gas_Pedal();
		CarPart gt=new Gas_Tank();
		CarPart headlights=new Headlights();
		CarPart muffler=new Muffler();
		CarPart radiator=new Radiator();
		CarPart seats=new Seats();
		CarPart speedometer=new Speedometer();
		CarPart sw=new Steering_Wheel();
		CarPart suspension=new Suspension();
		CarPart transmission=new Transmission();
		CarPart wheels=new Wheels();
		
		collection.add(alternator);
		collection.add(axles);
		collection.add(battery);
		collection.add(body);
		collection.add(brakes);
		collection.add(cc);
		collection.add(engine);
		collection.add(frame);
		collection.add(gp);
		collection.add(gt);
		collection.add(headlights);
		collection.add(muffler);
		collection.add(radiator);
		collection.add(seats);
		collection.add(speedometer);
		collection.add(sw);
		collection.add(suspension);
		collection.add(transmission);
		collection.add(wheels);
		
		
		};
		
		
		public void run() {
			
			int itemCount=collection.size();
			for (int i=0; i<itemCount; i++) {
				collection.get(i).function();
				
			}
			
			
		};

	}
