package dp;

public class Axles extends CarPart {
	
	public final int number=2;
	
	public void revolve() {
		
	}
	
	public void function() {
		System.out.println("[Axles: These parts connect and "
				+ "rotate the tires and there are two.]");
	}

}
