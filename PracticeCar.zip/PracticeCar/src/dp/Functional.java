package dp;

public interface Functional {
	
	public void function();

}
